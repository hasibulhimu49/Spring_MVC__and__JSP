package springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.view.RedirectView;


@Controller
public class RedirectController {
    
//Using Redirect prefix
//    @RequestMapping("/one")
//    public String One()
//    {        
//        System.out.println("This is one handler.");
//        return "redirect:/enjoy";
//    }
//    
//    
//    @RequestMapping("/enjoy")
//    public String Second()
//    {
//        System.out.println("This is second handler(engjoy).");
//        return "";
//    }
    
      
//using Redirect View
    @RequestMapping("/one")
    public RedirectView One()
    {        
        System.out.println("This is one handler.");
        RedirectView r=new RedirectView();
        r.setUrl("enjoy"); //relative path
//      r.setUrl("https://www.google.com");
        return r;
    }
    
    
    @RequestMapping("/enjoy")
    public String Second()
    {
        System.out.println("This is second handler(engjoy).");
        return "";
    }
   
    
    
}
