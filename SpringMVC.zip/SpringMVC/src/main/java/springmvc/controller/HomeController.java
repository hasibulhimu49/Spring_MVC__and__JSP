package springmvc.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.print.attribute.standard.DateTimeAtCompleted;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/first")
public class HomeController {
    
    @RequestMapping(path = "/about",method = RequestMethod.POST)
    public String about()
    {
        System.out.println("This is abooout url");
        System.out.flush();
        return "about";
    } 
    
    
    
//   Sending data from controller to view  (Model)
    @RequestMapping("/home")   //fire
    public String home(Model model) {
        System.out.println("This is Hommme url");
        System.out.flush();
        
        model.addAttribute("name","Mohammad Hasibul Khan");
        model.addAttribute("id",319);
        List<String> friends=new ArrayList<String>();
        friends.add("Sajid");
        friends.add("Tasnia");
        friends.add("Nasim");
        
        model.addAttribute("fnd",friends);
              
        return "index";  // must match index.jsp
    }
    
    
    
//    Sending data from controller to view  (ModelAndView)
    @RequestMapping("/help")
    public ModelAndView help()
    {
        System.out.println("This is helppp url");
        
        //creating modelandview object
        ModelAndView modelAndView=new ModelAndView();
        
        //settting the data
        modelAndView.addObject("name", "Brac Bank");
        
        LocalDateTime now =LocalDateTime.now();
        DateTimeFormatter dateTimeFormatter=DateTimeFormatter.ofPattern("HH:mm:ss  dd-MMMM-yyyy");
        String formatTime=now.format(dateTimeFormatter);
        
        // Pass the formatted time to the view
        modelAndView.addObject("time",formatTime);
        
        
        //marks
        List<Integer> list=new ArrayList<Integer>();
        list.add(87);
        list.add(90);
        list.add(345);
        list.add(846);
        list.add(95);
        list.add(99);

        modelAndView.addObject("marks",list);
        
        //setting the view name
        modelAndView.setViewName("help");
        
        return modelAndView;

    }  
    
}
