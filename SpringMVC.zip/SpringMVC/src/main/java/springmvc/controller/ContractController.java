package springmvc.controller;

import java.net.http.HttpRequest;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import springmvc.model.User;
import springmvc.service.userService;


@Controller
public class ContractController {
    
    @Autowired
    private userService userservice;
    
    @ModelAttribute
    public void commondataforModel(Model model)
    {
        model.addAttribute("heading","Please submit your information");
        model.addAttribute("description","Hello everyone I am Mohammad Hasibul Hasan.");
    }
    

     
    @RequestMapping("/contract")   //handler
    public String showForm()
    {
        return ("contract");
    }
    
    
//for servlet (old way data fetching)
    
 /*   @RequestMapping( path = "/processform", method=RequestMethod.POST )
    public String handleForm(HttpServletRequest request)
    {
        String email=request.getParameter("email");
        System.out.println("my email is: "+email);
        
        return "";
    }*/
    

//for spring mvc (new way data fetching using @RequestParam)
    
   /* @RequestMapping(path="/processform", method=RequestMethod.POST)
    public String handleForm(
            @RequestParam("email") String userEmail,
            @RequestParam("userName") String Name,
            @RequestParam("userPassword") String Password, Model model)
    {
        System.out.println("user email: "+userEmail);
        System.out.println("user name: "+Name);
        System.out.println("user password: "+Password);
        
        model.addAttribute("email",userEmail);
        model.addAttribute("name",Name);
        model.addAttribute("password",Password);
        return "success";
    }*/
    
    
   //for spring mvc (new way data fetching using @ModelAttribute)

    /**
     *
     * @param user
     * @param model
     * @return
     */
    
 @RequestMapping(path = "/processform", method = RequestMethod.POST)
    public String handleForm(@ModelAttribute User user, Model model) {
       System.out.println(user);
       
       if(user.getUserName().isBlank())
       {
           return "redirect:/contract";
       }
       
       int createUser=this.userservice.createUser(user);
       model.addAttribute("msg","User Created with Id: "+createUser);
        return "success";
    }   
}
